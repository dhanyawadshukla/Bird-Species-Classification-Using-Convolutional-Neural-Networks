import sys
import os
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader,Subset
from torchvision import transforms
import pandas as pd
from PIL import Image
import time
import csv
from sklearn.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt

torch.manual_seed(0)
# Custom ImageDataset Function to load the Image Dataset from the root directory Train
class CustomImageDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.image_paths = []
        self.labels = []
        # Iterate over each subfolder (0 to 9) in the root directory
        
        for label in range(10):
            folder_path = os.path.join(root_dir, str(label))
            for img_name in os.listdir(folder_path):
                img_path = os.path.join(folder_path, img_name)
                self.image_paths.append(img_path)
                self.labels.append(label)

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = Image.open(img_path).convert("RGB")  # Convert to RGB for color images
        label = self.labels[idx]
        
        if self.transform:
            image = self.transform(image)
            
        return image, label

# Transform all the images to the same size so that we can feed them to the neural Network    
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
    transforms.ToTensor(),
])

# CNN model for multi-class classification
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        
        self.bn1 = nn.BatchNorm2d(3)
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1)  # 3 input channels for RGB
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        
        self.bn2 = nn.BatchNorm2d(16)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        
        self.bn3 = nn.BatchNorm2d(32)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        
        self.bn4 = nn.BatchNorm2d(64)
        self.conv4 = nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1)
        self.pool4 = nn.MaxPool2d(kernel_size=2, stride=1, padding=0)
        
        self.bn5 = nn.BatchNorm2d(128)
        self.conv5 = nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1)
        self.pool5 = nn.MaxPool2d(kernel_size=2, stride=1, padding=0)
        
        self.dropout_conv = nn.Dropout(0)
        
        # Adjust input dimension for fc1 based on the expected output dimensions of conv layers
        self.fc1 = nn.Linear(256 * 14 * 14, 256)
        self.dropout_fc = nn.Dropout(0.25)
        self.fc2 = nn.Linear(256, 64)
        
        # New fully connected layer for classification
        self.dropout_fc3 = nn.Dropout(0.25)
        self.fc3 = nn.Linear(64, 10)  # 10 output classes for multi-class classification

    def forward(self, x):
        x = self.bn1(x)
        x = self.pool1(F.relu(self.conv1(x)))
        x = self.bn2(x)
        x = self.pool2(F.relu(self.conv2(x)))
        x = self.bn3(x)
        x = self.pool3(F.relu(self.conv3(x)))
        x = self.bn4(x)
        x = self.pool4(F.relu(self.conv4(x)))
        x = self.bn5(x)
        x = self.pool5(F.relu(self.conv5(x)))
        x = self.dropout_conv(x)

        # Flatten for the fully connected layer
        x = x.view(-1, 256 * 14 * 14)  # Adjusted for the output dimension after conv layers
        
        x = self.dropout_fc(x)
        x = F.relu(self.fc1(x))
        x = self.dropout_fc3(x)
        x = F.relu(self.fc2(x))
        x = self.fc3(x)  # Final output layer for 10 classes
        
        return x
    
# Model handling multi-class classification
class MyModel(CNN):
    def __init__(self):
        super(MyModel, self).__init__()

    def train_model(self, train_loader, validation_loader, num_epochs, learning_rate, max_time, device,weights,model_pth):
        
        optimizer = optim.Adam(self.parameters(), lr=learning_rate, weight_decay=0.003)
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.5)
        weights = torch.tensor(weights, device=device,dtype=torch.float32)
        # loss_fn = nn.CrossEntropyLoss(weight=weights)
        loss_fn = nn.CrossEntropyLoss()

        metrics = {'train_loss': [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
        start_time = time.time()
        best_val_accuracy = 0  # Initialize the best validation accuracy

        for epoch in range(num_epochs):
            # Check if the maximum time limit has been reached
            elapsed_time = (time.time() - start_time) / 60  # Convert to minutes
            if elapsed_time > max_time:
                print(f"Maximum training time of {max_time} minutes reached. Stopping training.")
                break

            self.train()
            running_loss = 0.0
            correct = 0
            total = 0

            # Training loop
            for images, labels in train_loader:
                images, labels = images.float().to(device), labels.long().to(device)
                optimizer.zero_grad()
                outputs = self(images)
                loss = loss_fn(outputs, labels)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                correct += (predicted == labels).sum().item()
                total += labels.size(0)

            train_loss = running_loss / len(train_loader)
            train_accuracy = correct / total * 100
            metrics['train_loss'].append(train_loss)
            metrics['train_acc'].append(train_accuracy)
            print(f"Epoch [{epoch + 1}], Loss: {train_loss:.4f}, Accuracy: {train_accuracy:.2f}%")

            # Evaluate on validation set
            self.eval()
            val_running_loss = 0.0
            correct = 0
            total = 0
            with torch.no_grad():
                for images, labels in validation_loader:
                    images, labels = images.float().to(device), labels.long().to(device)
                    outputs = self(images)
                    val_loss = loss_fn(outputs, labels)
                    val_running_loss += val_loss.item()
                    _, predicted = torch.max(outputs.data, 1)
                    correct += (predicted == labels).sum().item()
                    total += labels.size(0)

            val_loss = val_running_loss / len(validation_loader)
            val_accuracy = correct / total * 100
            metrics['val_loss'].append(val_loss)
            metrics['val_acc'].append(val_accuracy)

            # Save the model if validation accuracy is the best
            if val_accuracy > best_val_accuracy:
                best_val_accuracy = val_accuracy
                # save model
                PATH = model_pth
                torch.save(self.state_dict(), PATH)

            elapsed_time = (time.time() - start_time) / 60  # Convert to minutes
            print(f"Test Accuracy after Epoch [{epoch + 1}]: {val_accuracy:.2f}%")
            print(f"Time elapsed: {elapsed_time:.2f} minutes")

            scheduler.step()
            # Check the learning rate of the optimizer
            current_lr = optimizer.param_groups[0]['lr']
            print(current_lr)
            # Change step size to 5 if the learning rate is 0.001 or lesser
            if current_lr < 0.001 and scheduler.step_size != 5:
                scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)
        return metrics
class Pipeline:
    def __init__(self, root_dir,model_pth, num_epochs=50, learning_rate=0.001, max_time=100, device='cpu'):
        
        # Data Preprocessing and Data Loading
        # Initialize your full dataset
        full_dataset = CustomImageDataset(root_dir=root_dir, transform=transform)
        

        # Weights for handling of class imbalance
        weights = 10 * [0]
        for images,label in full_dataset:
            weights[label] += 1
        weights[weights == 0] = np.inf
        weights = np.array(weights, dtype=np.float32)
        weights=1/weights
        
        # Get the total number of samples
        dataset_size = len(full_dataset)
        print(dataset_size)
        # Generate indices for the entire dataset
        indices = np.arange(dataset_size)

        # Use train_test_split to split indices into training and testing 80:20
        train_indices, test_indices = train_test_split(indices, test_size=0.2, random_state=42,shuffle=True)

        # Use Subset to create train and test datasets based on indices
        train_dataset = Subset(full_dataset, train_indices)
        validation_dataset = Subset(full_dataset, test_indices)

        # Create dataloaders for each subset
        self.train_dataloader = DataLoader(train_dataset, batch_size=128, shuffle=True)
        self.validation_dataloader = DataLoader(validation_dataset, batch_size=128, shuffle=False)
        self.model = MyModel().to(device)

        # Calculate the number of parameters
        num_params = sum(p.numel() for p in self.model.parameters())
        print(f"Total number of parameters: {num_params}")

        self.max_time = max_time  # Maximum training time in minutes
        
        # Train the model
        metrics = self.model.train_model(self.train_dataloader, self.validation_dataloader, num_epochs, learning_rate, max_time, device,weights,model_pth)
        
        # Plot the training and validation metrics
        plot_metrics(metrics, save_path = "training_metrics.png")
        
def plot_metrics(metrics, save_path=None):
    epochs = list(range(1, len(metrics['train_loss']) + 1))
        
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.plot(epochs, metrics['train_loss'], label='Train Loss')
    plt.plot(epochs, metrics['val_loss'], label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Loss Curve')
    plt.legend()
        
    plt.subplot(1, 2, 2)
    plt.plot(epochs, metrics['train_acc'], label='Train Accuracy')
    plt.plot(epochs, metrics['val_acc'], label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Accuracy Curve')
    plt.legend()

    if save_path:
        plt.savefig(save_path)
        print(f"Metrics plotted and saved to {save_path}")
    else:
        plt.show()


def test_model(model, test_loader, device, output_csv='bird.csv'):
    model.eval()  
    total = 0
    results = []
    with torch.no_grad():  
        for images, _ in test_loader:
            images = images.to(device)
            # Forward pass
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            # Save predicted labels
            results.extend(predicted.cpu().numpy())

    # Write only predicted labels to a CSV file
    with open(output_csv, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Predicted_Label'])
        for label in results:
            writer.writerow([label])
    
def main():
    if len(sys.argv) != 4:
        print("Usage: python bird.py <data_path> <mode> <model_path>")
        sys.exit(1)

    # Parse arguments
    root_dir = sys.argv[1]
    mode = sys.argv[2]
    model_path = sys.argv[3]
    max_time = 110  # Maximum training time in minutes

    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(device)

    if mode == "train":
        print("training")
        # Initialize pipeline
        Pipeline(root_dir,model_path, num_epochs=100, learning_rate=0.002, max_time=max_time, device=device)
    elif mode == "test":
        print("infer")
        PATH = model_path
        model = MyModel().to(device)
        model.load_state_dict(torch.load(PATH))
        model.eval()
        test_dataset = CustomImageDataset(root_dir=root_dir, transform=transform)
        batch_size = 1
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
        test_model(model,test_loader,device)
    else:
        print("Invalid mode. Use 'train' or 'test'.")
        sys.exit(1)
    
if __name__ == "__main__": 
    main()